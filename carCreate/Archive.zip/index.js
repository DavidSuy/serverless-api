'use strict';

const dynamoose = require('dynamoose');

const schema = new dynamoose.Schema({
  carId: {
    type: String,
    required: true,
  },
  make: String,
  model: String,
  color: String,
  transmission: String,
});

const CarModel = dynamoose.model('cars', schema);

exports.handler = async (event) => {
  let newCar = new CarModel({
    carId: '5',
    make: 'honda',
    model: 'nsx',
    color: 'red',
    transmission: 'manual',
  });
  let newCarRecord = await newCar.save();

  console.log(newCarRecord);

  return {
    statusCode: 200,
    body: JSON.stringify(newCarRecord),
  };
};
