'use strict';

const dynamoose = require('dynamoose');

const schema = new dynamoose.Schema({
  carId: {
    type: String,
    required: true,
  },
  make: String,
  model: String,
  color: String,
  transmission: String,
});

const CarModel = dynamoose.model('cars', schema);

exports.handler = async (event) => {
  let carData = [];

  console.log(event);

  // carData = await CarModel.query('carId').eq(event.carId).exec();
  // if(event.pathParameters &&)
  carData = await CarModel.scan().exec();

  console.log(carData);

  return {
    status: 200,
    body: JSON.stringify(carData),
  };
};
